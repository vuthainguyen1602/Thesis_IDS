SOICT 2026 poster, paper 3215 (A0 portrait, 841 x 1189 mm)

main.tex       LaTeX source (XeLaTeX; tikz, qrcode, fontspec)
figures/       result plots from the paper (PDF)
img/           affiliation and organiser logos
SOICT2026_Poster_3215.pptx   PowerPoint version (one A0 slide, image of the PDF)

Build:  xelatex main.tex  (run twice: TikZ page overlays need the .aux)
        ->  main.pdf, one A0 page
Font: Helvetica Neue if installed, else TeX Gyre Heros.
